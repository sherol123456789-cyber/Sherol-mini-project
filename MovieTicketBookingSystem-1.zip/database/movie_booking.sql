CREATE DATABASE IF NOT EXISTS movie_booking;
USE movie_booking;

CREATE TABLE IF NOT EXISTS movies (
 movie_id INT PRIMARY KEY AUTO_INCREMENT,
 movie_name VARCHAR(100) NOT NULL,
 genre VARCHAR(50),
 duration VARCHAR(20),
 language VARCHAR(30) DEFAULT 'English',
 price DECIMAL(10,2) NOT NULL
);

CREATE TABLE IF NOT EXISTS customers (
 customer_id INT PRIMARY KEY AUTO_INCREMENT,
 customer_name VARCHAR(100) NOT NULL,
 phone VARCHAR(15) NOT NULL
);

CREATE TABLE IF NOT EXISTS bookings (
 booking_id INT PRIMARY KEY AUTO_INCREMENT,
 customer_id INT NOT NULL,
 movie_id INT NOT NULL,
 seats VARCHAR(200) NOT NULL,
 seat_category VARCHAR(20) NOT NULL,
 food_combo VARCHAR(50),
 ticket_total DECIMAL(10,2) NOT NULL,
 food_total DECIMAL(10,2) NOT NULL,
 total_price DECIMAL(10,2) NOT NULL,
 booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (customer_id) REFERENCES customers(customer_id),
 FOREIGN KEY (movie_id) REFERENCES movies(movie_id)
);

INSERT INTO movies (movie_name,genre,duration,language,price) VALUES
('Inception','Sci-Fi','2h 28m','English',150),
('Interstellar','Sci-Fi','2h 49m','English',180),
('The Dark Knight','Action','2h 32m','English',170),
('Avengers: Endgame','Action','3h 1m','English',200),
('Oppenheimer','Drama','3h','English',190),
('Avatar: The Way of Water','Fantasy','3h 12m','English',220);
